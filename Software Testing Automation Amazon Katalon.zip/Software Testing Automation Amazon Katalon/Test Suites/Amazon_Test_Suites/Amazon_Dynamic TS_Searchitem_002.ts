<?xml version="1.0" encoding="UTF-8"?>
<FilteringTestSuiteEntity>
   <description></description>
   <name>Amazon_Dynamic TS_Searchitem_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>d2bc98c7-251a-4ead-aca6-7b27b09e097b</testSuiteGuid>
   <filteringBuiltIn>com.kms.katalon.execution.platform.DynamicBuiltInSearch</filteringBuiltIn>
   <filteringExtension></filteringExtension>
   <filteringPlugin></filteringPlugin>
   <filteringText>tag=(smoke) </filteringText>
</FilteringTestSuiteEntity>
