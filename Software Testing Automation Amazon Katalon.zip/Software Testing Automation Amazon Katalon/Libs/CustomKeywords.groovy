
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "com.searchitem.two.CustomFunctionstwo.printlnHello"() {
    (new com.searchitem.two.CustomFunctionstwo()).printlnHello()
}


def static "com.SingIn.one.CustomFunctionsone.printlnHello"() {
    (new com.SingIn.one.CustomFunctionsone()).printlnHello()
}


def static "com.headerbutton.three.CustomFuncctionthree.printlnHello"() {
    (new com.headerbutton.three.CustomFuncctionthree()).printlnHello()
}


def static "com.footerlinks.four.CustomFunctionsfour.printlnHello"() {
    (new com.footerlinks.four.CustomFunctionsfour()).printlnHello()
}
